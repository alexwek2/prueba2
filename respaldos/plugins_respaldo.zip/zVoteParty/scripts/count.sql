CREATE TABLE IF NOT EXISTS zvoteparty_count
(
    vote long not null
)
comment 'Count vote for party';

